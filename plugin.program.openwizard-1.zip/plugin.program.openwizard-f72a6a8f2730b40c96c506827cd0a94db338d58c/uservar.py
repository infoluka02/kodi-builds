import xbmcaddon
import os

#########################################################
#          Global Variables - DON'T EDIT!!!             #
#########################################################
ADDON_ID = xbmcaddon.Addon().getAddonInfo('id')
PATH = xbmcaddon.Addon().getAddonInfo('path')
ART = os.path.join(PATH, 'resources', 'media')
#########################################################

#########################################################
#         User Edit Variables                           #
#########################################################
ADDONTITLE = '[COLOR limegreen][B]MSO[/B][/COLOR] Event Wizard'
BUILDERNAME = 'MSO Wizard'
EXCLUDES = [ADDON_ID, 'repository.openwizard']

# Link RAW chuẩn đét trỏ thẳng về file text hiển thị bản build của sếp
BUILDFILE = 'https://raw.githubusercontent.com/infoluka02/kodi-builds/main/builds.txt'

UPDATECHECK = 0
APKFILE = 'http://'
YOUTUBETITLE = ''
YOUTUBEFILE = 'http://'
ADDONFILE = 'http://'
ADVANCEDFILE = 'http://'
#########################################################

#########################################################
#         Theming Menu Items                            #
#########################################################
ICONBUILDS = os.path.join(ART, 'builds.png')
ICONMAINT = os.path.join(ART, 'maintenance.png')
ICONSPEED = os.path.join(ART, 'speed.png')
ICONAPK = os.path.join(ART, 'apkinstaller.png')
ICONADDONS = os.path.join(ART, 'addoninstaller.png')
ICONYOUTUBE = os.path.join(ART, 'youtube.png')
ICONSAVE = os.path.join(ART, 'savedata.png')
ICONTRAKT = os.path.join(ART, 'keeptrakt.png')
ICONREAL = os.path.join(ART, 'keepdebrid.png')
ICONLOGIN = os.path.join(ART, 'keeplogin.png')
ICONCONTACT = os.path.join(ART, 'information.png')
ICONSETTINGS = os.path.join(ART, 'settings.png')

HIDESPACERS = 'No'
SPACER = '='

# Đã dọn sạch đống cấu hình .format() lỗi font, đưa về chuỗi thô an toàn tuyệt đối
THEME1 = u'[COLOR limegreen][B]MSO Wizard[/B][/COLOR] > [COLOR white]%s[/COLOR]'
THEME2 = u'[COLOR limegreen]%s[/COLOR]'
THEME3 = u'[COLOR limegreen]%s[/COLOR]'
THEME4 = u'[COLOR limegreen]Current Build:[/COLOR] [COLOR white]%s[/COLOR]'
THEME5 = u'[COLOR limegreen]Current Theme:[/COLOR] [COLOR white]%s[/COLOR]'

HIDECONTACT = 'No'
CONTACT = 'MSO Event Wizard - He thong cai dat rap phim tu dong.'
CONTACTICON = os.path.join(ART, 'qricon.png')
CONTACTFANART = 'http://'
#########################################################

#########################################################
#         Auto Update For Those With No Repo            #
#########################################################
# Đóng về No để chặn tự động lội lên kho cũ của tác giả gây lỗi
AUTOUPDATE = 'No'
#########################################################

#########################################################
#         Auto Install Repo If Not Installed             #
#########################################################
AUTOINSTALL = 'No'
REPOID = ''
REPOADDONXML = ''
REPOZIPURL = ''
#########################################################

#########################################################
#         Notification Window                           #
#########################################################
ENABLE = 'No'
NOTIFICATION = 'http://'
HEADERTYPE = 'Text'
FONTHEADER = 'Font14'
HEADERMESSAGE = '[COLOR limegreen][B]MSO[/B][/COLOR] Wizard'
HEADERIMAGE = 'http://'
FONTSETTINGS = 'Font13'
BACKGROUND = 'http://'
#########################################################